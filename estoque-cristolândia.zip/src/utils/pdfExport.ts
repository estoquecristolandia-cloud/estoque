import jsPDF from 'jspdf';
import { Product, StockMovement } from '../types';

export function generateInventoryPDF(
  products: Product[],
  movements: StockMovement[],
  title = 'Relatório Oficial de Controle de Estoque'
) {
  const doc = new jsPDF();
  const now = new Date();
  const dateStr = now.toLocaleDateString('pt-BR');
  const timeStr = now.toLocaleTimeString('pt-BR');

  // Header Banner
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, 210, 32, 'F');

  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('JUNTA DE MISSÕES NACIONAIS - CBB', 14, 12);

  doc.setFontSize(11);
  doc.setTextColor(245, 158, 11); // amber-500
  doc.text('CENTRO DE FORMAÇÃO E ASSISTÊNCIA SOCIAL CRISTOLÂNDIA (LEM/BA)', 14, 19);

  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225); // slate-300
  doc.text(`Gerado em: ${dateStr} às ${timeStr} | Documento de Auditoria e Controle Interno`, 14, 26);

  // Document Title
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(title.toUpperCase(), 14, 42);

  // Summary Metrics Bar
  const totalProducts = products.length;
  const criticalProducts = products.filter((p) => p.currentStock <= p.minStock).length;
  const warningProducts = products.filter(
    (p) => p.currentStock > p.minStock && p.currentStock <= p.minStock * 1.5
  ).length;

  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(14, 46, 182, 14, 'F');

  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  doc.text(`Total de Itens Cadastrados: ${totalProducts}`, 18, 55);
  doc.text(`Itens Críticos (Reposição Urgente): ${criticalProducts}`, 85, 55);
  doc.text(`Itens em Alerta: ${warningProducts}`, 150, 55);

  // Table Headers
  let y = 68;
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(14, y, 182, 8, 'F');

  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('PRODUTO / ITEM', 18, y + 5.5);
  doc.text('CATEGORIA', 85, y + 5.5);
  doc.text('ESTOQUE', 130, y + 5.5);
  doc.text('MÍNIMO', 155, y + 5.5);
  doc.text('SITUAÇÃO', 178, y + 5.5);

  y += 8;

  // Table Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);

  products.forEach((p, index) => {
    if (y > 270) {
      doc.addPage();
      y = 20;

      // Repeat Table Headers on new page
      doc.setFillColor(30, 41, 59);
      doc.rect(14, y, 182, 8, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(255, 255, 255);
      doc.text('PRODUTO / ITEM', 18, y + 5.5);
      doc.text('CATEGORIA', 85, y + 5.5);
      doc.text('ESTOQUE', 130, y + 5.5);
      doc.text('MÍNIMO', 155, y + 5.5);
      doc.text('SITUAÇÃO', 178, y + 5.5);
      y += 8;
      doc.setFont('helvetica', 'normal');
    }

    // Zebra striping
    if (index % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y, 182, 7, 'F');
    }

    doc.setTextColor(15, 23, 42);
    // Truncate long names
    const prodName = p.name.length > 35 ? p.name.substring(0, 32) + '...' : p.name;
    doc.text(prodName, 18, y + 5);
    doc.text(p.category || 'Geral', 85, y + 5);
    doc.text(`${p.currentStock} ${p.unit}`, 130, y + 5);
    doc.text(`${p.minStock} ${p.unit}`, 155, y + 5);

    // Status Badge text & color
    if (p.currentStock <= p.minStock) {
      doc.setTextColor(225, 29, 72); // rose-600
      doc.setFont('helvetica', 'bold');
      doc.text('CRÍTICO', 178, y + 5);
      doc.setFont('helvetica', 'normal');
    } else if (p.currentStock <= p.minStock * 1.5) {
      doc.setTextColor(217, 119, 6); // amber-600
      doc.setFont('helvetica', 'bold');
      doc.text('ALERTA', 178, y + 5);
      doc.setFont('helvetica', 'normal');
    } else {
      doc.setTextColor(16, 185, 129); // emerald-500
      doc.text('OK', 178, y + 5);
    }

    y += 7;
  });

  // Footer Signatures
  y = Math.max(y + 15, 240);
  if (y > 260) {
    doc.addPage();
    y = 220;
  }

  doc.setLineWidth(0.5);
  doc.setDrawColor(203, 213, 225);

  doc.line(20, y, 90, y);
  doc.line(120, y, 190, y);

  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('Responsável pelo Almoxarifado / Estoque', 25, y + 5);
  doc.text('Coordenação Cristolândia LEM/BA', 130, y + 5);

  // Download PDF
  doc.save(`Relatorio_Estoque_Cristolandia_${now.toISOString().split('T')[0]}.pdf`);
}
